import { useState } from 'react';
import Circle from './Circle';
import { Square } from './Square';
import './main.css';

export default function App() {
    const [theme, setTheme] = useState({primary: 'theme1', secondary: 'theme2'})

    const handleSwitch = () => {
        const {primary, secondary} = theme;
        setTheme({primary: secondary, secondary: primary})
    }

    return (
        <div className='wrapper'>
            <div className='leftWrapper'>
                <Circle type='parent' theme={theme.primary}>
                    <Square type='child'/>
                </Circle>
                <Square type='parent' theme={theme.secondary}>
                    <Circle type='child'/>
                </Square>
            </div>
            <div className='rightWrapper'>
                <button onClick={handleSwitch}>Switch</button>
            </div>
        </div>
    )
}
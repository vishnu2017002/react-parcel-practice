export default function Circle({children, type, theme}) {
    return (
        <div className={(type === 'parent' ? 'parentElement' : 'childElement')+ ' circleWrapper '+theme}>
            {children || null}
        </div>
    )
}
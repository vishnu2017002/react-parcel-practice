export function Square({children, type, theme}) {
    return (
        <div className={(type === 'parent' ? 'parentElement' : 'childElement')+ ' squareWrapper '+(theme)}>
            {children || null}
        </div>
    )
}